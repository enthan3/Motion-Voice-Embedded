#include "stm32f7xx_hal.h"
#include "string.h"
#include "Gesture.h"
#define MAX7219_CS_PORT GPIOB
#define MAX7219_CS_PIN GPIO_PIN_11




extern SPI_HandleTypeDef hspi1;

void MAX7219_SetRow(uint8_t row, uint8_t data);
void MAX7219_DisplayDigit(uint8_t pos, uint8_t num);
void MAX7219_Init();
void Dotmatrix_Clear();
void Dotmatrix_DisplayGestureByName(const char *label);
void Dotmatrix_DisplayGesture(GestureType gesture);

