#ifndef __GESTURE_H__
#define __GESTURE_H__

typedef enum {
    GESTURE_HELLO,      // 0
    GESTURE_THANK_YOU,  // 1
    GESTURE_YES,        // 2
    GESTURE_NO,         // 3
    GESTURE_PLEASE,     // 4
    GESTURE_SORRY,      // 5
    GESTURE_HELP,       // 6
    GESTURE_MORE,       // 7
    GESTURE_EAT,        // 8
    GESTURE_DRINK,      // 9
    GESTURE_HAPPY,      // 10
    GESTURE_SAD,        // 11
    GESTURE_SLEEP,      // 12
    GESTURE_COLD,       // 13
    GESTURE_HOT,        // 14
    GESTURE_BOOK,       // 15
    GESTURE_OUTSIDE,    // 16
    GESTURE_STOP,       // 17
    GESTURE_TODAY,      // 18
    GESTURE_TOMORROW,
    GESTURE_TOTAL
} GestureType;

#endif  // __GESTURE_H__
